package edu.cmich.cps542;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.SystemMenuBar;

public class ClosestPair {

	public static void main(String[] args) {
		try {
			/* load data from points.txt here */
			BufferedReader reader = new BufferedReader(
					new FileReader("e:\\Analysis And Design of Algorithms\\PP1-ClosestPair\\points.txt"));
			String line;
			ArrayList<Point> points = new ArrayList<>();
			while ((line = reader.readLine()) != null) {
				points.add(getPointFromLine(line));
			}

			// Close reader.
			reader.close();

			// PointPair nearestPointPair = bruteClosestPair(points);
			// System.out.println(nearestPointPair);

			/* use your sort method here */
			ArrayList<Point> pointsXOrdered = sort(points, true);
			ArrayList<Point> pointsYOrdered = sort(points, false);

			/* call efficientClosestPair here */
			System.out.println(efficientClosestPair(pointsXOrdered, pointsYOrdered));

		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static PointPair efficientClosestPair(ArrayList<Point> pointsXOrdered, ArrayList<Point> pointsYOrdered) {
		int n = pointsXOrdered.size();
		if (n <= 3) {
			return bruteClosestPair(pointsXOrdered);
		}

		int mid = n / 2;
		ArrayList<Point> pL = new ArrayList<>();
		ArrayList<Point> qL = new ArrayList<>();
		ArrayList<Point> pR = new ArrayList<>();
		ArrayList<Point> qR = new ArrayList<>();

		for (int i = 0; i < mid; i++) {
			pL.add(pointsXOrdered.get(i));
		}

		for (int i = 0; i < mid; i++) {
			qL.add(pointsYOrdered.get(i));
		}

		for (int i = mid; i < n; i++) {
			pR.add(pointsXOrdered.get(i));
		}

		for (int i = mid; i < n; i++) {
			qR.add(pointsYOrdered.get(i));
		}

		PointPair dL = efficientClosestPair(pL, qL);
		PointPair dR = efficientClosestPair(pR, qR);
		double dlDistance = dL.distBetweenPoints();
		double drDistance = dR.distBetweenPoints();

		double d = Math.min(dlDistance, drDistance);
		double m = pointsXOrdered.get((int) (Math.ceil(mid) - 1)).x;
		double dMinSqr = Math.pow(d, 2);
		PointPair minPair;
		if (dlDistance == d) {
			minPair = dL;
		} else {
			minPair = dR;
		}

		ArrayList<Point> S = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			if (Math.abs(pointsYOrdered.get(i).x - m) < d) {
				S.add(pointsYOrdered.get(i));
			}
		}

		int num = S.size();

		for (int i = 0; i < num - 2; i++) {
			int k = i + 1;
			while (k <= num - 1 && Math.pow((S.get(i).y - S.get(k).y), 2) < dMinSqr) {
				minPair = new PointPair(S.get(k), S.get(i));
				dMinSqr = Math.min(dMinSqr, minPair.distSqrdBetweenPoints());
				k++;
			}
		}

		return minPair;

	}

	public static PointPair bruteClosestPair(ArrayList<Point> points) {
		PointPair pointPair = new PointPair(points.get(0), points.get(1));
		PointPair nearestPointPair = pointPair;
		double distance = pointPair.distBetweenPoints();
		for (int i = 0; i < points.size(); i++) {
			for (int j = i + 1; j < points.size(); j++) {
				PointPair currPointPair = new PointPair(points.get(i), points.get(j));
				double currentDistance = currPointPair.distBetweenPoints();
				if (currentDistance < distance) {
					distance = currentDistance;
					nearestPointPair = currPointPair;
				}
			}
		}

		return nearestPointPair;

	}

	public static ArrayList<Point> sort(ArrayList<Point> points, boolean sortXCoordinates) {

		/*
		 * No call to sort method here. Implement something that is divide-
		 * -and-conquer and O(n log n)
		 */
		int n = points.size();
		ArrayList<Point> sortedPoints = new ArrayList<>();
		sortedPoints.addAll(mergeSort(points, 0, n - 1, sortXCoordinates));

		return sortedPoints;
	}

	public static ArrayList<Point> mergeSort(ArrayList<Point> points, int l, int r, boolean sortXCoordinates) {
		if (l < r) {
			int m = l + (r - l) / 2;

			mergeSort(points, l, m, sortXCoordinates);
			mergeSort(points, m + 1, r, sortXCoordinates);

			merge(points, l, m, r, sortXCoordinates);
		}
		return points;
	}

	public static void merge(ArrayList<Point> points, int l, int m, int r, boolean sortXCoordinates) {
		// System.out.println("l: " + l + ", m: " + m + ", r: " + r);
		// Sizes of left and right sub arrays.
		int p = m - l + 1;
		int q = r - m;

		// Create two temporary arrays.
		ArrayList<Point> pointsL = new ArrayList<>();
		ArrayList<Point> pointsR = new ArrayList<>();

		for (int i = 0; i < p; ++i)
			pointsL.add(points.get(l + i));
		for (int j = 0; j < q; ++j)
			pointsR.add(points.get(m + 1 + j));

		// Initial indices.
		int i = 0, j = 0;
		// Initial index of merged sub array.
		int k = l;
		while (i < p && j < q) {
			double a, b;
			if (sortXCoordinates) {
				a = pointsL.get(i).x;
				b = pointsR.get(j).x;
			} else {
				a = pointsL.get(i).y;
				b = pointsR.get(j).y;
			}

			if (a <= b) {
				points.set(k, pointsL.get(i));
				i++;
			} else {
				points.set(k, pointsR.get(j));
				j++;
			}
			k++;
		}

		/* Copy remaining elements of L[] if any */
		while (i < p) {
			points.set(k, pointsL.get(i));
			i++;
			k++;
		}

		/* Copy remaining elements of R[] if any */
		while (j < q) {
			points.set(k, pointsR.get(j));
			j++;
			k++;
		}
	}

	public static Point getPointFromLine(String line) {
		Pattern pattern = Pattern.compile("[+-]?([0-9]*[.])?[0-9]+");
		Matcher matcher = pattern.matcher(line);
		matcher.find();
		String x = matcher.group();
		matcher.find();
		String y = matcher.group();
		return new Point(Double.parseDouble(x), Double.parseDouble(y));
	}
}
